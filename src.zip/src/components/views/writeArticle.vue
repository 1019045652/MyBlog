<template>
  <div>
    <div>
      <h1>写博客页面</h1>
    <pre>加油干！</pre>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style>
</style>
